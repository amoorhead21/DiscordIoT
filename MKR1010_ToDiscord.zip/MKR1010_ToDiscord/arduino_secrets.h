#define SECRET_SSID ""
#define SECRET_PASS ""
#define SECRET_WEBHOOK ""
#define SECRET_TTS ""
